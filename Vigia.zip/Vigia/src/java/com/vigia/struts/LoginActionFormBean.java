/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vigia.struts;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

/**
 *
 * @author hsendoa
 */
public class LoginActionFormBean extends org.apache.struts.action.ActionForm {

    private String name;
    private int number;
    private String username;
    private String password;
    private String error = "error por default";
/*metodos Getters and Setters*/
    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }
    private String email;

    public void setUsername(String username) {
        this.username = username;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     * @param string
     */
    public void setName(String string) {
        name = string;
    }

    /**
     * @return
     */
    public int getNumber() {
        return number;
    }

    /**
     * @param i
     */
    public void setNumber(int i) {
        number = i;
    }

    /**
     * Constructor por defecto
     */
    public LoginActionFormBean() {
        super();
        // TODO Auto-generated constructor stub
    }
/*En caso de querer usar el validador de Struts 1.3.10 pueden completar esta parte.*/
    /**
     * This is the action called from the Struts framework.
     *
     * @param mapping The ActionMapping used to select this instance.
     * @param request The HTTP Request we are processing.
     * @return
     */
//    public ActionErrors validate(ActionMapping mapping, HttpServletRequest request) {
//        ActionErrors errors = new ActionErrors();
//        if (getName() == null || getName().length() < 1) {
//            errors.add("loginError", new ActionMessage("HOLA"));
//            //this.setError("Usuario o Clave Invalida");
//            // TODO: add 'error.name.required' key to your resources
//            return errors;
//            
//        }
//        return null;
//    }
}
