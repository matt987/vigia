/*
 * Clase Menu, se encarga de obner y armar el menu de la BD
 */
package com.vigia.struts.vo;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletContext;

/**
 *
 * @author hsendoa
 */
public class Menu {

    private int _idUsuario = 0;
    private UserVO _user;

    public Menu(String usuario) {
        _user = new UserVO(usuario);
        _user.validar();
    }

    public String getMenu() {
        String menu = "<ul class='navbar-nav'>";

        Conexion con = new Conexion();
        ResultSet rs = null;
        String consulta = "select * from vigia.sitemap t where t.perfil like '%admin%' and t.padre=0";

        //Logger.getLogger(UserVO.class.getName()).log(Level.INFO, consulta, "-");
        try {
            rs = con.ejecutaSQL(consulta);
            while (rs.next()) {
                menu += "<li class='navbar-text navbar-link' >";
                menu += "<a href='" + rs.getString("url") + "' class='dropdown-toggle' data-toggle='dropdown' data-hover='dropdown'>" + rs.getString("nombre");
                if (rs.getInt("hijos") == 1) {
                    menu += "<b class='caret'></b></a>";

                    menu += "<ul class='dropdown-menu'>";
                    String subconsulta = "select * from vigia.sitemap t where t.perfil like '%admin%' and t.padre=" + rs.getInt("id_sitemap");

                    ResultSet rsSub = con.ejecutaSQL(subconsulta);
                    while (rsSub.next()) {
                        menu += "<li>";
                        menu += "<a href='" + rsSub.getString("url") + "'>" + rsSub.getString("nombre") + "</a></li>";

                    }
                    menu += "</ul>";
                } else {
                    menu += "</a>";
                }

                menu += "</li>";

                //break;//una sola ves consulta
            }
        } catch (SQLException ex) {
            Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException | IOException ex) {
            Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
        }
        menu += "</ul>";
        //Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, menu);
        return menu;
    }

}
